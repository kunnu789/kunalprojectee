export const sections = {
    "personal_details": "Personal Details",
    "work_experience": "Work Experience",
    "projects": "Projects",
    "education": "Education",
    "achievments": "Achievements",
    "skills": "Skills",
    "other": "Other"
};
