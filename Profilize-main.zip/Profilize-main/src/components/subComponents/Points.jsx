import InputComponent from '../InputComponent';

const Points = (props) => {
    return (
        <div>
            <InputComponent {...props}/>
        </div>
    );
}

export default Points;
