
const SliderButton = (props) => {
    return (
        <>
            <div {...props} >
                {props.text}
            </div>
        </>
    );
}

export default SliderButton;
